from setuptools import setup, find_packages

VERSION = '0.1.20240603070355'

requires = [
        'cachetools==5.3.3',
        'requests==2.31.0',
        'httpx==0.27.0',
        'boto3==1.34.84'
    ]

setup(
    name="llm_idam_token_generator",
    version=VERSION,
    description="A Python-based SDK for generating IDAM token to connect LLM models",
    # include_package_data=True,
    packages=find_packages(),
    author='GE HealthCare',
    author_email='sateesh.uppara@gehealthcare.com',
    license='Proprietary',
    platforms=['Windows', 'Linux', 'macOS'],
    url='https://www.gehealthcare.com',
    package_data={'': ['*.*']},
    classifiers=[
        "Intended Audience :: Developers",
        "Natural Language :: English",
        'Programming Language :: Python :: 3.11',
    ],
    install_requires=requires
)